package com.ortowhave;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrtoWhaveApplication {

    public static void main(String[] args) {
        SpringApplication.run(OrtoWhaveApplication.class, args);
    }
}
