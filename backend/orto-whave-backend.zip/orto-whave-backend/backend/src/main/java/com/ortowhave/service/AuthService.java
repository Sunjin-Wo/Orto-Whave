package com.ortowhave.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ortowhave.dto.request.LoginRequest;
import com.ortowhave.dto.request.PatientRegisterRequest;
import com.ortowhave.dto.request.VerifyPatientRequest;
import com.ortowhave.dto.response.JwtResponse;
import com.ortowhave.exception.EmailAlreadyExistsException;
import com.ortowhave.exception.InvalidVerificationCodeException;
import com.ortowhave.exception.PhoneNumberAlreadyExistsException;
import com.ortowhave.exception.ResourceNotFoundException;
import com.ortowhave.model.PendingRegistration;
import com.ortowhave.model.User;
import com.ortowhave.repository.PendingRegistrationRepository;
import com.ortowhave.repository.UserRepository;
import com.ortowhave.security.jwt.JwtUtils;
import com.ortowhave.security.service.UserDetailsImpl;

import java.time.LocalDateTime;
import java.util.Random;

@Service
public class AuthService {
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private PendingRegistrationRepository pendingRegistrationRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Autowired
    private JwtUtils jwtUtils;
    
    @Autowired
    private AuthenticationManager authenticationManager;
    
    @Autowired
    private EmailService emailService;
    
    /**
     * Registra un paciente pendiente de verificación
     */
    @Transactional
    public String registerPatient(PatientRegisterRequest registerRequest) {
        // Verificar si el email ya existe en usuarios
        if (userRepository.existsByEmail(registerRequest.getEmail())) {
            throw new EmailAlreadyExistsException("Email ya registrado");
        }
        
        // Verificar si el teléfono ya existe en usuarios
        if (userRepository.existsByPhoneNumber(registerRequest.getPhoneNumber())) {
            throw new PhoneNumberAlreadyExistsException("Número de teléfono ya registrado");
        }
        
        // Verificar si ya existe un registro pendiente con ese email
        pendingRegistrationRepository.findByEmail(registerRequest.getEmail())
            .ifPresent(pendingReg -> pendingRegistrationRepository.delete(pendingReg));
        
        // Generar código de verificación (6 dígitos)
        String verificationCode = generateVerificationCode();
        
        // Crear registro pendiente
        PendingRegistration pendingRegistration = new PendingRegistration();
        pendingRegistration.setFirstName(registerRequest.getFirstName());
        pendingRegistration.setLastName(registerRequest.getLastName());
        pendingRegistration.setEmail(registerRequest.getEmail());
        pendingRegistration.setPassword(passwordEncoder.encode(registerRequest.getPassword()));
        pendingRegistration.setPhoneNumber(registerRequest.getPhoneNumber());
        pendingRegistration.setVerificationCode(verificationCode);
        pendingRegistration.setVerified(false);
        
        pendingRegistrationRepository.save(pendingRegistration);
        
        // Enviar email con código de verificación
        emailService.sendVerificationEmail(registerRequest.getEmail(), verificationCode);
        
        return "Se ha enviado un código de verificación a su correo electrónico";
    }
    
    /**
     * Verifica el código de un paciente y crea su cuenta
     */
    @Transactional
    public JwtResponse verifyPatient(VerifyPatientRequest verifyRequest) {
        // Buscar registro pendiente
        PendingRegistration pendingRegistration = pendingRegistrationRepository.findByEmail(verifyRequest.getEmail())
            .orElseThrow(() -> new ResourceNotFoundException("No se encontró registro pendiente para este email"));
        
        // Verificar que el código sea correcto
        if (!pendingRegistration.getVerificationCode().equals(verifyRequest.getVerificationCode())) {
            throw new InvalidVerificationCodeException("Código de verificación inválido");
        }
        
        // Verificar que el código no haya expirado
        if (pendingRegistration.getExpirationDate().isBefore(LocalDateTime.now())) {
            pendingRegistrationRepository.delete(pendingRegistration);
            throw new InvalidVerificationCodeException("El código de verificación ha expirado");
        }
        
        // Crear usuario
        User user = new User();
        user.setFirstName(pendingRegistration.getFirstName());
        user.setLastName(pendingRegistration.getLastName());
        user.setEmail(pendingRegistration.getEmail());
        user.setPassword(pendingRegistration.getPassword()); // Ya está encriptada
        user.setPhoneNumber(pendingRegistration.getPhoneNumber());
        user.setRole(User.ROLE_PATIENT);
        user.setUserType(User.TYPE_PATIENT);
        user.setActive(true);
        
        userRepository.save(user);
        
        // Eliminar registro pendiente
        pendingRegistrationRepository.delete(pendingRegistration);
        
        // Autenticar usuario y generar token
        Authentication authentication = authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(verifyRequest.getEmail(), pendingRegistration.getPassword())
        );
        
        SecurityContextHolder.getContext().setAuthentication(authentication);
        String jwt = jwtUtils.generateJwtToken(authentication);
        
        return new JwtResponse(
            jwt,
            user.getId(),
            user.getFirstName() + " " + user.getLastName(),
            user.getEmail(),
            user.getRole(),
            user.getUserType(),
            "/patient/dashboard"
        );
    }
    
    /**
     * Inicia sesión y devuelve información del usuario con su dashboard correspondiente
     */
    public JwtResponse login(LoginRequest loginRequest) {
        // Autenticar usuario
        Authentication authentication = authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(loginRequest.getEmail(), loginRequest.getPassword())
        );
        
        SecurityContextHolder.getContext().setAuthentication(authentication);
        
        // Generar token JWT
        String jwt = jwtUtils.generateJwtToken(authentication);
        
        UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
        
        // Obtener usuario completo para acceder al tipo
        User user = userRepository.findById(userDetails.getId())
            .orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado"));
        
        // Determinar la URL del dashboard según el tipo de usuario
        String dashboardUrl;
        switch (user.getUserType()) {
            case User.TYPE_ADMIN:
                dashboardUrl = "/admin/dashboard";
                break;
            case User.TYPE_DOCTOR:
                dashboardUrl = "/doctor/dashboard";
                break;
            case User.TYPE_PATIENT:
                dashboardUrl = "/patient/dashboard";
                break;
            default:
                dashboardUrl = "/";
                break;
        }
        
        return new JwtResponse(
            jwt,
            userDetails.getId(),
            userDetails.getFirstName() + " " + userDetails.getLastName(),
            userDetails.getEmail(),
            userDetails.getAuthorities().iterator().next().getAuthority(),
            user.getUserType(),
            dashboardUrl
        );
    }
    
    public boolean validateToken(String token) {
        return jwtUtils.validateJwtToken(token);
    }
    
    /**
     * Genera un código de verificación de 6 dígitos
     */
    private String generateVerificationCode() {
        Random random = new Random();
        int code = 100000 + random.nextInt(900000); // Genera un número entre 100000 y 999999
        return String.valueOf(code);
    }
}
