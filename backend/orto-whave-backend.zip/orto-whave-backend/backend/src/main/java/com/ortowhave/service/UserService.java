package com.ortowhave.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ortowhave.dto.response.UserResponse;
import com.ortowhave.exception.ResourceNotFoundException;
import com.ortowhave.exception.UnauthorizedOperationException;
import com.ortowhave.model.User;
import com.ortowhave.repository.UserRepository;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    public List<UserResponse> getAllUsers() {
        List<User> users = userRepository.findAll();
        return users.stream().map(this::mapToUserResponse).collect(Collectors.toList());
    }
    
    public UserResponse getUserById(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado con id: " + id));
        return mapToUserResponse(user);
    }
    
    public UserResponse getUserByEmail(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("Usuario no encontrado con email: " + email));
        return mapToUserResponse(user);
    }
    
    @Transactional
    public UserResponse createUser(String firstName, String lastName, String email, 
                                  String password, String phoneNumber, String userType) {
        // Validar que solo se puedan crear usuarios de tipo DOCTOR o ADMIN
        if (!User.TYPE_DOCTOR.equals(userType) && !User.TYPE_ADMIN.equals(userType)) {
            throw new UnauthorizedOperationException("Solo se pueden crear usuarios de tipo DOCTOR o ADMIN");
        }
        
        // Determinar el rol basado en el tipo de usuario
        String role;
        if (User.TYPE_DOCTOR.equals(userType)) {
            role = User.ROLE_DOCTOR;
        } else if (User.TYPE_ADMIN.equals(userType)) {
            role = User.ROLE_ADMIN;
        } else {
            throw new IllegalArgumentException("Tipo de usuario no válido");
        }
        
        User user = new User();
        user.setFirstName(firstName);
        user.setLastName(lastName);
        user.setEmail(email);
        user.setPassword(passwordEncoder.encode(password));
        user.setPhoneNumber(phoneNumber);
        user.setRole(role);
        user.setUserType(userType);
        user.setActive(true);
        
        User savedUser = userRepository.save(user);
        return mapToUserResponse(savedUser);
    }
    
    @Transactional
    public UserResponse updateUser(Long id, String firstName, String lastName, 
                                  String phoneNumber, Boolean active) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado con id: " + id));
        
        user.setFirstName(firstName);
        user.setLastName(lastName);
        user.setPhoneNumber(phoneNumber);
        user.setActive(active);
        
        User updatedUser = userRepository.save(user);
        return mapToUserResponse(updatedUser);
    }
    
    @Transactional
    public UserResponse updateUserRole(Long id, String userType) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado con id: " + id));
        
        // Validar que solo se puedan asignar tipos válidos
        if (!User.TYPE_DOCTOR.equals(userType) && !User.TYPE_ADMIN.equals(userType) && !User.TYPE_PATIENT.equals(userType)) {
            throw new IllegalArgumentException("Tipo de usuario no válido");
        }
        
        // Determinar el rol basado en el tipo de usuario
        String role;
        if (User.TYPE_DOCTOR.equals(userType)) {
            role = User.ROLE_DOCTOR;
        } else if (User.TYPE_ADMIN.equals(userType)) {
            role = User.ROLE_ADMIN;
        } else {
            role = User.ROLE_PATIENT;
        }
        
        user.setUserType(userType);
        user.setRole(role);
        
        User updatedUser = userRepository.save(user);
        return mapToUserResponse(updatedUser);
    }
    
    @Transactional
    public void deleteUser(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado con id: " + id));
        
        userRepository.delete(user);
    }
    
    private UserResponse mapToUserResponse(User user) {
        UserResponse response = new UserResponse();
        response.setId(user.getId());
        response.setFirstName(user.getFirstName());
        response.setLastName(user.getLastName());
        response.setEmail(user.getEmail());
        response.setPhoneNumber(user.getPhoneNumber());
        response.setRole(user.getRole());
        response.setUserType(user.getUserType());
        response.setActive(user.getActive());
        response.setRegistrationDate(user.getRegistrationDate());
        return response;
    }
}
