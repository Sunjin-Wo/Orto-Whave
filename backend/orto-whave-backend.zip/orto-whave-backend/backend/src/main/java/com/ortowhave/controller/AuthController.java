package com.ortowhave.controller;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ortowhave.dto.request.LoginRequest;
import com.ortowhave.dto.request.PatientRegisterRequest;
import com.ortowhave.dto.request.VerifyPatientRequest;
import com.ortowhave.dto.response.JwtResponse;
import com.ortowhave.dto.response.MessageResponse;
import com.ortowhave.service.AuthService;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*", maxAge = 3600)
public class AuthController {
    @Autowired
    private AuthService authService;
    
    @PostMapping("/register/patient")
    public ResponseEntity<?> registerPatient(@Valid @RequestBody PatientRegisterRequest registerRequest) {
        String response = authService.registerPatient(registerRequest);
        return ResponseEntity.ok(new MessageResponse(response));
    }
    
    @PostMapping("/verify/patient")
    public ResponseEntity<?> verifyPatient(@Valid @RequestBody VerifyPatientRequest verifyRequest) {
        JwtResponse jwtResponse = authService.verifyPatient(verifyRequest);
        return ResponseEntity.ok(jwtResponse);
    }
    
    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody LoginRequest loginRequest) {
        JwtResponse jwtResponse = authService.login(loginRequest);
        return ResponseEntity.ok(jwtResponse);
    }
    
    @PostMapping("/validate")
    public ResponseEntity<?> validateToken(@RequestHeader("Authorization") String token) {
        if (token != null && token.startsWith("Bearer ")) {
            token = token.substring(7);
        }
        boolean isValid = authService.validateToken(token);
        return ResponseEntity.ok(new MessageResponse(isValid ? "Token válido" : "Token inválido"));
    }
}
