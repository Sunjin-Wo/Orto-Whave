# Documentación de la estructura actual de autenticación y registro

## Estructura general

El sistema actual de orto-whave tiene una arquitectura basada en Spring Boot con los siguientes componentes principales:

### Controladores
- **AuthController**: Maneja el registro y login de usuarios
- **AdminController**: Gestiona operaciones administrativas sobre usuarios
- **UserController**: Operaciones generales de usuarios
- **DoctorController**: Operaciones específicas para doctores
- **PatientController**: Operaciones específicas para pacientes

### Servicios
- **AuthService**: Implementa la lógica de autenticación y registro
- **UserService**: Gestiona operaciones CRUD de usuarios
- **EmailService**: Maneja el envío de correos electrónicos

### Modelos
- **User**: Entidad principal para todos los usuarios
- **Role**: Entidad para roles
- **Permission**: Entidad para permisos
- **RolePermission**: Relación entre roles y permisos
- **PendingRegistration**: Entidad para registros pendientes

### Seguridad
- **JwtUtils**: Utilidades para generación y validación de tokens JWT
- **AuthTokenFilter**: Filtro para autenticación basada en JWT
- **UserDetailsImpl/UserDetailsServiceImpl**: Implementación de detalles de usuario para Spring Security

## Flujo actual de autenticación y registro

### Registro de usuarios
1. El registro actual solo permite crear usuarios con rol "ROLE_USER"
2. No existe diferenciación entre tipos de usuarios (pacientes, doctores, administradores)
3. No hay proceso de verificación por código para pacientes
4. El registro es directo sin validación adicional

### Creación de usuarios por administrador
1. El administrador puede crear usuarios con cualquier rol mediante el AdminController
2. No hay restricciones específicas para la creación de doctores o administradores
3. El administrador puede actualizar roles de usuarios existentes

### Inicio de sesión
1. El proceso de login es estándar usando email y contraseña
2. Se genera un token JWT que incluye información del usuario y su rol
3. No hay redirección específica según el tipo de usuario

## Limitaciones identificadas

1. **Falta de flujo diferenciado para pacientes**: No existe un proceso específico de registro con código de verificación para pacientes.
2. **Sin restricción para creación de roles privilegiados**: No hay una lógica que restrinja la creación de doctores y administradores exclusivamente al administrador.
3. **Ausencia de dashboard específico por rol**: No hay redirección automática al dashboard correspondiente según el rol del usuario.
4. **Modelo de usuario único**: Se utiliza una sola entidad User para todos los tipos de usuarios, sin diferenciación clara entre pacientes, doctores y administradores.
5. **Verificación de email no implementada**: Aunque existe un modelo PendingRegistration, no se utiliza para verificación de nuevos registros.

## Cambios necesarios

1. Implementar registro con código de verificación exclusivamente para pacientes
2. Restringir la creación de doctores y administradores solo al administrador
3. Asegurar la redirección al dashboard correspondiente según el rol
4. Mejorar la gestión de roles para diferenciar claramente entre pacientes, doctores y administradores
5. Implementar el envío de correos con códigos de verificación para pacientes
