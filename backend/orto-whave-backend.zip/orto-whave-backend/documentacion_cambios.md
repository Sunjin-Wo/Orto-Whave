# Documentación de cambios realizados en orto-whave

## Resumen de cambios

Se ha rediseñado el sistema de autenticación y registro para implementar los siguientes flujos:

1. **Registro de pacientes**: Ahora con código de verificación enviado por email
2. **Gestión de doctores y administradores**: Exclusivamente por el administrador
3. **Redirección a dashboard**: Automática según el rol del usuario

## Cambios en el modelo de datos

### Modelo User
- Se agregó el campo `userType` para diferenciar entre PATIENT, DOCTOR y ADMIN
- Se mantiene el campo `role` para compatibilidad con Spring Security
- Se agregaron constantes para tipos de usuario y roles

```java
public static final String TYPE_PATIENT = "PATIENT";
public static final String TYPE_DOCTOR = "DOCTOR";
public static final String TYPE_ADMIN = "ADMIN";

public static final String ROLE_PATIENT = "ROLE_PATIENT";
public static final String ROLE_DOCTOR = "ROLE_DOCTOR";
public static final String ROLE_ADMIN = "ROLE_ADMIN";
```

## Nuevos DTOs implementados

### PatientRegisterRequest
- DTO específico para el registro de pacientes

### VerifyPatientRequest
- DTO para la verificación de código de pacientes

### CreateUserRequest
- Actualizado para incluir userType y role

### JwtResponse
- Actualizado para incluir userType y dashboardUrl

## Cambios en los servicios

### AuthService
- Nuevo método `registerPatient`: Crea un registro pendiente y envía código por email
- Nuevo método `verifyPatient`: Valida el código y crea el usuario paciente
- Modificación de `login`: Ahora incluye información del dashboard según el rol

### UserService
- Modificación de `createUser`: Ahora solo permite crear usuarios DOCTOR o ADMIN
- Modificación de `updateUserRole`: Ahora actualiza tanto el rol como el tipo de usuario

### EmailService
- Se mantiene sin cambios, ya estaba implementado para enviar códigos de verificación

## Cambios en los controladores

### AuthController
- Nuevo endpoint `/api/auth/register/patient`: Para registro de pacientes
- Nuevo endpoint `/api/auth/verify/patient`: Para verificación de código
- Modificación de `/api/auth/login`: Ahora devuelve información del dashboard

### AdminController
- Modificación de `/api/admin/users`: Ahora solo permite crear doctores y administradores
- Cambio de `/api/admin/users/{id}/role` a `/api/admin/users/{id}/type`: Para actualizar el tipo de usuario

## Flujos de trabajo implementados

### Registro de pacientes
1. El paciente se registra a través de `/api/auth/register/patient`
2. Se crea un registro pendiente y se envía código por email
3. El paciente verifica su cuenta con el código a través de `/api/auth/verify/patient`
4. Se crea el usuario con tipo PATIENT y rol ROLE_PATIENT

### Creación de doctores y administradores
1. Solo un administrador puede crear estos usuarios a través de `/api/admin/users`
2. Se especifica el tipo (DOCTOR o ADMIN) y el rol correspondiente
3. No requiere verificación por código

### Inicio de sesión
1. El usuario inicia sesión a través de `/api/auth/login`
2. El sistema devuelve un token JWT con información del dashboard
3. El frontend redirige al usuario al dashboard correspondiente

## Configuración de puertos

Se ha mantenido la configuración original de puertos:
- Backend: Puerto 8081
- phpMyAdmin: Configuración original sin cambios

## Seguridad

- Se mantiene la autenticación basada en JWT
- Se ha reforzado la validación de roles para operaciones administrativas
- Se ha implementado la expiración de códigos de verificación (24 horas)

## Pruebas realizadas

- Registro de pacientes con código de verificación
- Creación de doctores y administradores por el administrador
- Inicio de sesión y redirección a dashboard según rol
- Validación de permisos para operaciones administrativas
